export function Footer(){
    return (
        <div className="bg-brand-dark m-auto text-center bottom-0 p-4 z-10 fixed w-full">
            <h2>Projeto desenvolvido por: Coti Informática</h2>
        </div>
    )
}