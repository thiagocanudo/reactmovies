export function NotFound(){
    return (
        <h1>\(º_º)/ 404</h1>
    )
}