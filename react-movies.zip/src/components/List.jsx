import { useEffect, useState } from "react";
import { getDados } from "../api/tmdb"

export default function({categoria}){

    const [items, setItens] = useState([]);
    // getDados(categoria);

    // não existe uma função 'awayt' sem que esteja dentro de uma função 'asyncrona'
    async function loadItems(){
        const data = await getDados(categoria); // aciona a API
        setItens(data); //Guarda os dados da API em um estado
    }

    // Função especial que é executada ao fim da renderização do componemte
    useEffect(() => {
        loadItems();
    }, []);


    return(
        <>
            <h4 className="text-center">Lista de {categoria}</h4>
            {console.log(items)}

            {
                items.map(item => (
                    <>
                    <h2 className="text-center">{item.title || item.name}</h2>
                    <img className="m-auto" src={`https://image.tmdb.org/t/p/w500/${item.poster_path}`} width="100" alt="" />
                    </>
                ))
            }
        </>
    )
}